namespace Ponorka
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


    }

    public struct Record
    {
        public int Time { get; init; }
        public double Depth { get; init; }

        public Record(int t, double d)
        {
            Time = t;
            Depth = d;
        }
    }
}