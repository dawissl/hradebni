﻿namespace Ponorka
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnCreateData = new Button();
            BtnLoadData = new Button();
            SuspendLayout();
            // 
            // BtnCreateData
            // 
            BtnCreateData.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            BtnCreateData.Location = new Point(12, 12);
            BtnCreateData.Name = "BtnCreateData";
            BtnCreateData.Size = new Size(193, 46);
            BtnCreateData.TabIndex = 0;
            BtnCreateData.Text = "Create data";
            BtnCreateData.UseVisualStyleBackColor = true;
            // 
            // BtnLoadData
            // 
            BtnLoadData.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            BtnLoadData.Location = new Point(12, 64);
            BtnLoadData.Name = "BtnLoadData";
            BtnLoadData.Size = new Size(193, 46);
            BtnLoadData.TabIndex = 1;
            BtnLoadData.Text = "Load data";
            BtnLoadData.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnLoadData);
            Controls.Add(BtnCreateData);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button BtnCreateData;
        private Button BtnLoadData;
    }
}