namespace NakupniKosik
{
    public partial class Form1 : Form
    {
        private Zbozi[] nakupniSeznam = new Zbozi[10];
        private int index = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            Zbozi z;            

            switch (ComboType.Text)
            {
                case "Zbo��":
                   z = new Zbozi(TxtName.Text, double.Parse(TxtPrice.Text));
                    break;

                case "Potravina":
                    break;
                case "Drogerie":
                    break;
                default:
                    return;
            }

            if (index < 10)
            {
                nakupniSeznam[index] = z;
                index++;
            }
            else
            {
                MessageBox.Show("Nakupn� ko��k je pln�");
                return;
            }

            LblShop.Text = "";
            double vyslednaCena = 0;
            for(int i = 0; i < index; i++)
            {
                LblShop.Text += nakupniSeznam[i].ToString() + Environment.NewLine;
                vyslednaCena += nakupniSeznam[i].Cena;
            }
            LblPrice.Text = $"{vyslednaCena} K�";

        }
    }

    class Zbozi
    {
        private string nazev;
        private double cena;

        public double Cena { get { return cena; }  }

        public Zbozi(string nazev, double c)
        {
            this.nazev = nazev;
            cena = c;
        }

        public override string ToString()
        {
            // $ = alt + 36
            return $"{nazev} - {cena} K�";
        }
    }
}